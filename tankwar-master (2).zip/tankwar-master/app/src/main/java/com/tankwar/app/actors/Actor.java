package com.tankwar.app.actors;


/**
 * Interface for all actors in the game.
 * <p>
 * <hr><b>&copy; Copyright 2010 Guidebee, Inc. All Rights Reserved.</b>
 *
 * @author Guidebee, Inc.
 * @version 1.00, 12/08/10
 */
public interface Actor {

    /**
     * Operation be done in each tick.
     *
     * @roseuid 652795A202AC
     */
    public void tick();
}
