package com.tankwar.app.actors.tank;


import com.tankwar.app.ResourceManager;
import com.tankwar.app.actors.BattleField;
import com.tankwar.app.actors.Score;

/**
 * Smart tank.
 * <p>
 * <hr><b>&copy; Copyright 2008 Guidebee, Inc. All Rights Reserved.</b>
 *
 * @author Guidebee, Inc.
 * @version 1.00, 18/01/08
 */
public final class SmartTank extends EnemyTank {

    /**
     * Constructor.
     *
     * @param hasPrize if true, when player hit the tank, a new powerup is put
     *                 in the battle field.
     */
    protected SmartTank(boolean hasPrize) {
        super(hasPrize);
        direction = BattleField.SOUTH;
        speed = ResourceManager.TILE_WIDTH / 2;
        score = Score.SCORE_300;
    }

    /**
     * Look for the player tank,if in the same row or col return true.
     *
     * @param dir current direction.
     * @return boolean
     */
    private boolean lookforPlayer(int dir) {
        return true;
    }

    /**
     * Tank thinks before move.
     *
     * @roseuid 652795A601E1
     */
    public void think() {

    }
}
