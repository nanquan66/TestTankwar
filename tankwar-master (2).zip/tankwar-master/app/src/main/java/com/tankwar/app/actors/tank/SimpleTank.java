package com.tankwar.app.actors.tank;


import com.tankwar.app.actors.Score;

/**
 * Simple tank.
 * <p>
 * <hr><b>&copy; Copyright 2008 Guidebee, Inc. All Rights Reserved.</b>
 *
 * @author Guidebee, Inc.
 * @version 1.00, 18/01/08
 */
public class SimpleTank extends EnemyTank {

    /**
     * Constructor.
     *
     * @param hasPrize if true, when player hit the tank, a new powerup is put
     *                 in the battle field.
     */
    protected SimpleTank(boolean hasPrize) {
       super(hasPrize);
       score= Score.SCORE_100;
    }

    /**
     * Tank thinks before move.
     */
    public void think() {

    }
}
