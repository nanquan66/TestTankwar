package com.tankwar.app.actors.tank;


import com.tankwar.app.ResourceManager;
import com.tankwar.app.actors.Score;

/**
 * Heavy tank.
 * <p>
 * <hr><b>&copy; Copyright 2008 Guidebee, Inc. All Rights Reserved.</b>
 *
 * @author Guidebee, Inc.
 * @version 1.00, 18/01/08
 */
public final class HeavyTank extends SimpleTank {

    /**
     * Constructor.
     *
     * @param hasPrize if true, when player hit the tank, a new powerup is put
     *                 in the battle field.
     * @roseuid 652795A50319
     */
    public HeavyTank(boolean hasPrize) {
        super(hasPrize);
        speed = ResourceManager.TILE_WIDTH / 6;
        type = TYPE_HEAVY;
        score = Score.SCORE_400;
    }
}
