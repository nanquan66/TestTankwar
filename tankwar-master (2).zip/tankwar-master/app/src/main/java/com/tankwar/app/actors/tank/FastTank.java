package com.tankwar.app.actors.tank;

import com.tankwar.app.ResourceManager;
import com.tankwar.app.actors.Score;

/**
 * Fast tank.
 * <p>
 * <hr><b>&copy; Copyright 2008 Guidebee, Inc. All Rights Reserved.</b>
 *
 * @author Guidebee, Inc.
 * @version 1.00, 18/01/08
 */
public final class FastTank extends SimpleTank {

    /**
     * Constructor.
     *
     * @param hasPrize if true, when player hit the tank, a new powerup is put
     *                 in the battle field.
     * @roseuid 652795A502C9
     */
    protected FastTank(boolean hasPrize) {
        super(hasPrize);
        speed = ResourceManager.TILE_WIDTH / 2;
        type = TYPE_FAST;
        score = Score.SCORE_200;
    }
}
